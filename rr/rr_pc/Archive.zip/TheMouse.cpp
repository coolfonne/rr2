#include "TheMouse.h"

TheMouse* TheMouse::instance = NULL;

